const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });
const mongoose = require('mongoose');
const Product  = require('../models/Product');

const products = [
  {
    name: 'ProBook Zenith X1', price: 3499, oldPrice: null, rating: 4.9,
    badge: 'New', category: 'laptop', wide: false,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBx5D2J6rrYYFNweL60mW5RL48m0CoNs6INMorhDfCgJtlMpVuQpegzMnVuMgcOMwMWCiObk3JrbQTlfA62MJf7K0DnJRnClzfsx4Z1EblpZh0FnyJ32OOsyWVH_geFu-vLjkWN9XWyzC8aNi5wbW4c_EEujJgS86XSuxPbEUsIKag3b0UHpAmrQNZ9TNsIrGLRSIz6ttyPq7yqCyLiJJnFDAdyr1ijLxXthkTcg-VHuCvGruIzR3ijWR_7yAXCBvwCJwD5EAE_5tU8',
    description: 'Ordinateur portable ultra-performant avec écran OLED 14" 120Hz, processeur Core Ultra 9 et batterie 72Wh.',
    specs: [['Processeur','Core Ultra 9'],['RAM','32 GB DDR5'],['Stockage','1 TB NVMe'],['Écran','14" OLED 120Hz']],
    stock: 5,
  },
  {
    name: 'Nebula S24 Ultra', price: 4150, oldPrice: null, rating: 4.8,
    badge: null, category: 'smartphone', wide: false,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCqLBiY1vIk0XZd1HYJCrenOr3bBAPrs6MWKjZ3bDR2R4TMs_YWeCNEvidDJTB2AZSy_XrMCo3F8ZqZWxkm4Zxxrt-QG24ClTeuOzlFYKQfmhOwV5x7LUbcVTz-wyQ2EahAlE5RqXEyslGqIKQ5Ws13uVQJLra7oMbWl-oIo279fMYfpgy13Xc-MDSayUSzxji1ytTHcWr35TeDuq4P0tl3XnHQ7E5BLb2VmIeqw8EPZzV0xXz0bFCWr_bIWYF7F2bqEbxXYR_jGPXk',
    description: 'Smartphone flagship avec capteur 200 MP, écran Dynamic AMOLED 6.8" et S Pen intégré.',
    specs: [['Écran','6.8" 120Hz'],['Appareil photo','200 MP'],['Batterie','5 000 mAh'],['OS','Android 14']],
    stock: 12,
  },
  {
    name: 'Kinetic Rig G9', price: 6890, oldPrice: 7500, rating: 5.0,
    badge: 'Promo', category: 'gaming', wide: true,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAVYnY9fcRFJO7AToTZkAuu9qiRQOud6T-DDd9vNg0OFucPHIDXcVvwNLmpxFFfB3i1C_1J3PLrWc5ltVWiicC9oauJr09qcusZegiq_S24fDRtoB38N-BcHVGp5yI9dxEMEf-pdA2mayP43Q8rJdfxDOTI1gNJvu5CGINvFUEgKCNpHTf_1ICHCx4sX-e77IBFUTjURASMysENkQ0L-1xp65izCmQEki98r8XJ_iyadBEpHnQVaaGZA5gkzwL5nUlRyEb4xK3tA0h2',
    description: 'Tour gaming haut de gamme avec RGB synchronisé, refroidissement liquide 360mm et alimentation 1000W 80+ Gold.',
    specs: [['GPU','RTX 4090'],['CPU','Ryzen 9 7950X'],['RAM','64 GB DDR5'],['Stockage','4 TB NVMe']],
    stock: 3,
  },
  {
    name: 'Sonic Pulse V2', price: 599, oldPrice: null, rating: 4.7,
    badge: null, category: 'audio', wide: false,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAs7QvL4KSF4oNYyjzgeEBTfwIl1UbzXzzShlcYXee6gWxn9flVHstUkcLLwCQl2gD0ajqRQg5lSc4oxKjXHnSuQfaacALHaw8UsZQXJa7DZZuLpW3NjikH-xCZMoBelnVZ2FREDDGBnI27tEtvpF1kHcG3pc5C7soKcr_-cGvRVFvFAr6uNP4ODjuMoQ0GIV_D0MfjIGFn7Wcn-fcpeYQZPh2Q2oshkYabm9BCA6BwbGrDFfMws2caqhqGIEHX7p_enORHksaByMJe',
    description: "Casque audiophile sans fil 40h d'autonomie, réduction de bruit active hybride et pilotes 40mm Premium.",
    specs: [['Autonomie','40 h'],['ANC','Hybride'],['Connectivité','Bluetooth 5.3'],['Pilotes','40 mm Premium']],
    stock: 8,
  },
  {
    name: 'Aura Watch GT', price: 820, oldPrice: null, rating: 4.6,
    badge: null, category: 'accessory', wide: false,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCDKXagfDhlrk0fzpg3443JLqdNTO3H6ob6MaZuuujb_TtuvmTD1ZjT85YeZuYU23J4N47Nkhgp1K0kuOsfYHmnPgwRrvfu1exTPr1GsxZUJp6yeh9Xka-4pqDRB5LAGoGLi4jRnSq9ceb1GG6Q0aAC1xpKpBcCAO87BWXnxXQERKnhm5gktJD11LRwTnQXpHfy5S5H5vZx51sNZ8LVOErZK9AlDW9O83HZvufAyIoCHd88MafDWZFoKJ-RKwX4aJAlakXjxhguIj5D',
    description: "Montre connectée avec suivi santé avancé, GPS intégré, écran AMOLED et résistance à l'eau 5 ATM.",
    specs: [['Écran','AMOLED 1.5"'],['GPS','Oui'],['Autonomie','14 jours'],['Résistance','5 ATM']],
    stock: 15,
  },
  {
    name: 'Titan Tab S10', price: 2100, oldPrice: null, rating: 4.8,
    badge: null, category: 'laptop', wide: false, icon: 'tablet_mac',
    description: 'Tablette premium 12.4" AMOLED avec stylet inclus, processeur Dimensity 9300 et 12 GB de RAM.',
    specs: [['Écran','12.4" AMOLED'],['Processeur','Dimensity 9300'],['RAM','12 GB'],['Stockage','256 GB']],
    stock: 6,
  },
  {
    name: 'Horizon Curve 34"', price: 1850, oldPrice: null, rating: 4.9,
    badge: null, category: 'accessory', wide: false, icon: 'monitor',
    description: 'Moniteur incurvé ultrawide 34" 165Hz QHD, compatible G-Sync et FreeSync Premium Pro.',
    specs: [['Taille','34" Ultrawide'],['Résolution','3440×1440'],['Fréquence','165 Hz'],['HDR','DisplayHDR 400']],
    stock: 4,
  },
  {
    name: 'Console X-Gen Pro', price: 2400, oldPrice: null, rating: 4.9,
    badge: null, category: 'gaming', wide: true, icon: 'videogame_asset',
    description: 'Console next-gen avec SSD 1 TB ultra-rapide, ray-tracing 4K 120fps et manette haptique.',
    specs: [['Résolution','4K 120fps'],['Stockage','1 TB SSD'],['Ray-tracing','Oui'],['Online','Inclus 1 an']],
    stock: 7,
  },
  {
    name: 'Apex Clicky RGB', price: 245, oldPrice: null, rating: 4.5,
    badge: null, category: 'accessory', wide: false, icon: 'keyboard',
    description: 'Clavier mécanique TKL RGB avec switches Blue Cherry MX, boîtier en aluminium anodisé.',
    specs: [['Switches','Cherry MX Blue'],['Layout','TKL (80%)'],['RGB','16M couleurs'],['Boîtier','Aluminium']],
    stock: 20,
  },
  {
    name: 'Velocity M1 Wireless', price: 180, oldPrice: null, rating: 4.7,
    badge: null, category: 'accessory', wide: false, icon: 'mouse',
    description: 'Souris gaming sans fil 26 000 DPI, capteur Hero 25K et autonomie 70h sans RGB.',
    specs: [['DPI','26 000'],['Capteur','Hero 25K'],['Autonomie','70 h'],['Poids','95 g']],
    stock: 18,
  },
  {
    name: 'CyberCam 4K Pro', price: 1290, oldPrice: 1490, rating: 4.8,
    badge: 'Promo', category: 'accessory', wide: false, icon: 'videocam',
    description: "Webcam 4K 60fps avec autofocus AI, annulation de bruit et éclairage HDR intégré.",
    specs: [['Résolution','4K 60fps'],['Autofocus','AI'],['Micro','Stéréo ANC'],['FOV','90°']],
    stock: 9,
  },
  {
    name: 'NanoBook Air Z', price: 2799, oldPrice: null, rating: 4.6,
    badge: 'New', category: 'laptop', wide: false, icon: 'laptop',
    description: "Ultrabook 13\" de 890g avec autonomie record de 22 heures et charge rapide 100W.",
    specs: [['Poids','890 g'],['Autonomie','22 h'],['Charge','100W USB-C'],['Écran','13" IPS 500nits']],
    stock: 10,
  },
  {
    name: 'VoltRide Pro X', price: 3490, oldPrice: 3990, rating: 4.9,
    badge: 'Promo', category: 'mobilite', wide: true, icon: 'electric_scooter',
    description: "Trottinette électrique haut de gamme — moteur 1000W, autonomie 65 km, suspension avant/arrière.",
    specs: [['Moteur','1000 W'],['Autonomie','65 km'],['Vitesse max','45 km/h'],['Charge','4 h']],
    stock: 5,
  },
  {
    name: 'Speeder S9 Ultra', price: 1890, oldPrice: null, rating: 4.7,
    badge: 'New', category: 'mobilite', wide: false, icon: 'electric_scooter',
    description: "Trottinette légère 12 kg avec pneus tubeless 10\", écran OLED et connectivité Bluetooth.",
    specs: [['Poids','12 kg'],['Autonomie','40 km'],['Pneus','10" Tubeless'],['Écran','OLED']],
    stock: 8,
  },
  {
    name: 'EcoBike Z7 City', price: 4290, oldPrice: null, rating: 4.8,
    badge: 'New', category: 'mobilite', wide: false, icon: 'directions_bike',
    description: "Vélo électrique urbain avec batterie intégrée au cadre, moteur central Bosch 250W.",
    specs: [['Moteur','Bosch 250W'],['Autonomie','80 km'],['Vitesses','7 Shimano'],['Poids','19 kg']],
    stock: 4,
  },
  {
    name: 'TrailBolt MTB-E', price: 6990, oldPrice: 7500, rating: 5.0,
    badge: 'Promo', category: 'mobilite', wide: false, icon: 'directions_bike',
    description: "VTT électrique tout-terrain avec fourche hydraulique, moteur mid-drive 750W.",
    specs: [['Moteur','750W Mid-Drive'],['Batterie','720 Wh'],['Fourche','Hydraulique'],['Freins','Shimano 4 pistons']],
    stock: 3,
  },
  {
    name: 'MiniRoll Pocket', price: 890, oldPrice: null, rating: 4.5,
    badge: null, category: 'mobilite', wide: false, icon: 'electric_scooter',
    description: "Trottinette compacte pliable en 3 secondes, idéale pour le dernier kilomètre.",
    specs: [['Poids','8.5 kg'],['Autonomie','25 km'],['Pliage','3 sec'],['Vitesse max','25 km/h']],
    stock: 12,
  },
  {
    name: 'Kit Casque + Lumières', price: 290, oldPrice: null, rating: 4.6,
    badge: null, category: 'mobilite', wide: false, icon: 'helmet',
    description: "Pack sécurité complet : casque certifié EN1078, éclairage avant 800 lm.",
    specs: [['Norme','EN1078'],['Lumière avant','800 lm'],['Feu arrière','Clignotant'],['Tailles','S/M/L/XL']],
    stock: 25,
  },
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connecté à MongoDB');
    await Product.deleteMany({});
    console.log('🗑️  Anciens produits supprimés');
    const inserted = await Product.insertMany(products);
    console.log(`✅ ${inserted.length} produits insérés :`);
    inserted.forEach(p => console.log(`   • ${p.name} — ${p.price} TND`));
  } catch (err) {
    console.error('❌ Erreur:', err.message);
  } finally {
    await mongoose.disconnect();
    console.log('\n✅ Terminé ! Lancez: npm start');
  }
}

seed();
