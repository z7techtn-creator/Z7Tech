const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
require('dotenv').config();

const app = express();

app.use(helmet());
app.use(morgan('dev'));
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('✅ MongoDB متصل'))
  .catch(err => { console.error('❌ خطأ MongoDB:', err.message); process.exit(1); });

app.use('/api/products', require('./routes/products'));
app.use('/api/cart',     require('./routes/cart'));
app.use('/api/orders',   require('./routes/orders'));
app.use('/api/admin',    require('./routes/admin'));

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Z7 Tech API تعمل ✅' });
});

app.use((req, res) => res.status(404).json({ success: false, message: 'المسار غير موجود' }));
app.use((err, req, res, next) => res.status(500).json({ success: false, message: 'خطأ في الخادم' }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Z7 Tech Server على المنفذ ${PORT}`));
