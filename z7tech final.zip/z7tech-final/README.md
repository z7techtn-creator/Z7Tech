# Z7 Tech — متجر إلكتروني تونسي 🇹🇳

## هيكل المشروع
```
Z7Tech/
├── Index.html          ← Frontend كامل
└── backend/
    ├── server.js
    ├── package.json
    ├── .env.example    ← انسخه إلى .env
    ├── models/         ← Product, Cart, Order
    ├── routes/         ← products, cart, orders, admin
    ├── middleware/     ← adminAuth
    └── scripts/        ← seedProducts (18 منتج)
```

## تشغيل سريع
```bash
cd backend
npm install
cp .env.example .env   # أضف MONGODB_URI
npm run seed           # أضف 18 منتج
npm start
```

ثم افتح `Index.html` في المتصفح.

## بعد النشر على Render
غيّر هذا السطر في `Index.html`:
```js
const API_BASE = 'https://YOUR-APP.onrender.com';
```

## انظر backend/.env.example للإعدادات
